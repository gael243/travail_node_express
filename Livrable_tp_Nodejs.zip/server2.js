const express=require('express');
const server=express();
const bodyparser=require('body-parser');
server.use(bodyparser.urlencoded({extended:false}));
server.use(bodyparser.json());

const PORT=3000;

const users = [
  {
    id:1,  
    nom: 'Lisangola',
    prenom: 'Christian',
    email: '',
    poste: 'Homme de ménage',
    numeroTelephone: ['+243908888888'],
    estMarie: false,
    pays: 'RDCongo',
  },
  {
    id:2,
    nom: 'Motoba',
    prenom: 'Claude',
    email: 'claude@gmail.com',
    poste: 'Architecte infrastructures',
    numeroTelephone: ['+243818885454', '+243844457484'],
    estMarie: true,
    pays: 'Liban',
  },
  {
    id:3,
    nom: 'Nyembo',
    prenom: 'Thesy',
    email: 'thesy.nyembo@gmail.com',
    poste: 'DevOPS & Développeuse Fullstack',
    numeroTelephone: ['+2438108488888', '+243844145444'],
    estMarie: false,
    pays: 'Djibouti',
  },
  {
    id:4,
    nom: 'Gael',
    prenom: 'Mapwata',
    email: 'mapwata.gael@gmail.com',
    poste: 'Administrateur systèmes & Réseaux',
    numeroTelephone: ['+243818897188', '+243844445744'],
    estMarie: true,
    pays: 'Inde',
  },
  {
    id:5,
    nom: 'Makengo',
    prenom: 'Stanislas',
    email: 'makengo.stanislas@gmail.com',
    poste: 'Chef de projet digital',
    numeroTelephone: ['+243814428888', '+243844446734'],
    estMarie: true,
    pays: 'Algérie',
  },
  {
      id:6,
    nom: 'Ndovia',
    prenom: 'Ruth',
    email: 'ruth.ndovia@gmail.com',
    poste: 'Administrateur systèmes & Réseaux',
    numeroTelephone: ['+24381458888', '+243844434444'],
    estMarie: false,
    pays: 'RDCongo',
  },
  {
    id:7,
    nom: 'Bondjali',
    prenom: 'Chris',
    email: '',
    poste: 'Cordonier',
    numeroTelephone: ['+24390999898'],
    estMarie: true,
    pays: 'RDCongo',
  },
];

server.get('/',function(req,res){
    res.send("Bienvenu dans notre page")
});

server.get('/api/users',(req,res)=>{
    res.send(users);
});

server.get('/api/users/:matricule',(req,res)=>{
    const user=users.find((user)=>user.id===parseInt(req.params.matricule));
    res.send(user);
})

//le code pour l'ajout dans mon tableau

server.post('/api/users',(req,res)=>{

    /**
     * pour ajouter un element dans un tableau on utilise la methode javascript push
    est ensuite on le passe en parametre notre requete qui sera l'objet ajouter dans notre tableau
    vue que cette Object sera sous format json je preferai inclure une nouvelle depense body-parser
    qui est contenu dans express.
     * 
     */
  
    users.push(req.body);
    res.send(users);
})

//le code pour supprimer un object à travers son id

server.delete('/api/users/:id',(req,res)=>{
    /**
     * alors pour supprimer un element specifique dans mon tableau, j'ai tout d'abord commencer par utilser
     * le verbe http delete en suite à l'interieur de ma fonction call back,j'ai commencer d'abord par déclarer une variable
     * contenant mon parametre, ensuite se suit de ma boucle qui me permet d'obtenir un id specifique en fin de le comparer
     * avec mon parametre, ensuite nous avons la methode splice qui me permet de supprimer l'object et cette
     * methode prend en parametre comme vous pouvez le voir l'indice ainsi que le nombre de ligne à supprimer
     * 
     */
    const identifiant=req.params.id;
    for(i in users){
        if(users[i].id==identifiant){
            users.splice(i,1);
        }
    }
    res.send(users)
})

//le code pour modifier un object à travers son id

server.put('/api/users/:id',(req,res)=>{
    /**
     * pour le code de la modification, comme vous le savez tous le verbe http à utiliser est put
     * est dans ma function callback j'ai toujours utiliser la methode javascript splice , mais cette fois
     *ci en l'ajoutant un autre parametre qui est mon object. 
     * 
     */
    const identifiant=req.params.id;
    for(i in users){
        if(users[i].id==identifiant){
            users.splice(i,1,req.body);
        }
    }
    res.send(users)
})

server.listen(PORT,function(){
    console.log(`Le serveur écoute sur le PORT ${PORT}`);
})








